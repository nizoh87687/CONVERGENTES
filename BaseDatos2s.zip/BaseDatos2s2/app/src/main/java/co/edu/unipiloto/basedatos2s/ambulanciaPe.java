package co.edu.unipiloto.basedatos2s;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ambulanciaPe extends AppCompatActivity {


    EditText edtUbicación;
    Button btnEnviarA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ambulancia);

        edtUbicación=(EditText)findViewById(R.id.edtUbicación);
        btnEnviarA=(Button) findViewById(R.id.btnEnviarA);


        final AmbulanciaDB ambulanciaDB=new AmbulanciaDB(getApplicationContext());

        btnEnviarA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //nelsen, el error de preguntale a tu mamá, preguntale a tu papá lo resolviste en esta linea cambiando el tipo de la variable final AmbulanciaDB ambulanciaDB=new AmbulanciaDB(getApplicationContext());
                ambulanciaDB.agregarUbicación(edtUbicación.getText().toString());
                Toast.makeText(getApplicationContext(),"se esta enviando una ambulancia a su ubicación",Toast.LENGTH_SHORT).show();
            }
        });

    }

}
