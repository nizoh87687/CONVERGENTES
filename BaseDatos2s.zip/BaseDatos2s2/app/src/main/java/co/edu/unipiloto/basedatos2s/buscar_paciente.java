package co.edu.unipiloto.basedatos2s;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class buscar_paciente extends AppCompatActivity {


    EditText edtNombre,edtEnfermedad,edtNumero;
    Button btnBuscar, sig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buscar_paciente);

        edtNombre=(EditText)findViewById(R.id.edtNombre);
        edtEnfermedad=(EditText)findViewById(R.id.Edtenfermedad);
        edtNumero=(EditText)findViewById(R.id.EdtNumero);
        btnBuscar=(Button) findViewById(R.id.btnBuscar);


        final DB DB=new DB(getApplicationContext());

        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pacienteGS paci=new pacienteGS();
                DB.BuscarP(paci,edtNombre.getText().toString());
                edtEnfermedad.setText(paci.getEnfermedad());
                edtNumero.setText(paci.getNumero());
            }
        });

    }

}
