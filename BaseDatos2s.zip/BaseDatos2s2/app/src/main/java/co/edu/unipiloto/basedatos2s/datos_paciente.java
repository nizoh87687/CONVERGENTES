package co.edu.unipiloto.basedatos2s;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class datos_paciente extends AppCompatActivity {

    EditText edtNombre,edtEnfermedad,edtNumero;
    Button btnAgregar, sig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datos_paciente);

        edtNombre=(EditText)findViewById(R.id.edtNombre);
        edtEnfermedad=(EditText)findViewById(R.id.Edtenfermedad);
        edtNumero=(EditText)findViewById(R.id.EdtNumero);
        btnAgregar=(Button) findViewById(R.id.btnAgregar);


        final DB DB=new DB(getApplicationContext());

        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DB.agregarPaciente(edtNombre.getText().toString(), edtEnfermedad.getText().toString(), edtNumero.getText().toString());
                Toast.makeText(getApplicationContext(),"OK",Toast.LENGTH_SHORT).show();
            }
        });
        final DB DB2=new DB(getApplicationContext()); //para usar los metodos que conforman la clase
        sig=(Button)findViewById(R.id.Sig);
        sig.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(datos_paciente.this, AmbulanciaDB.class);
                startActivity(intent);

            }
        });

    }
    }
