package co.edu.unipiloto.basedatos2s;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

    public class MainActivity extends AppCompatActivity {

        Button Registrarse, info, ambu;

        @SuppressLint("MissingInflatedId")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            final DB DB = new DB(getApplicationContext()); //para usar los metodos que conforman la clase
            Registrarse = (Button) findViewById(R.id.Registrarse);
            Registrarse.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, datos_paciente.class);
                    startActivity(intent);

                }
            });

            final DB DB2 = new DB(getApplicationContext()); //para usar los metodos que conforman la clase
            info = (Button) findViewById(R.id.información);
            info.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                     Intent intent = new Intent(MainActivity.this, buscar_paciente.class);
                    startActivity(intent);

                }
            });

            final DB DB3 = new DB(getApplicationContext()); //para usar los metodos que conforman la clase
            ambu = (Button) findViewById(R.id.ambulancia);
            ambu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, ambulanciaPe.class);
                    startActivity(intent);

                }
            });
        }
    }