package co.edu.unipiloto.basedatos2s;

public class pacienteGS {

    private String nombre, enfermedad, numero;

    public pacienteGS(){

    }
    public pacienteGS(String nombre, String enfermedad, String numero) {
        this.nombre = nombre;
        this.enfermedad = enfermedad;
        this.numero = numero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEnfermedad() {
        return enfermedad;
    }

    public void setEnfermedad(String enfermedad) {
        this.enfermedad = enfermedad;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
}
