package co.edu.unipiloto.basedatos2s;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {

    private static final String NOMBRE_DB="pacientes.db";
    private static final int VERSION_DB=1;
    private static final String TABLA_PACIENT="CREATE TABLE PACIENT(NOMBRE TEXT PRIMARY KEY, ENFERMEDAD TEXT, NUMERO TEXT)";


    public DB(Context context) {
        super(context, NOMBRE_DB, null, VERSION_DB);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(TABLA_PACIENT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLA_PACIENT);
        sqLiteDatabase.execSQL(TABLA_PACIENT);
    }

    public void agregarPaciente(String nombre, String enfermedad, String numero) {
    SQLiteDatabase bd=getWritableDatabase();
    if(bd!=null){
        bd.execSQL("INSERT INTO PACIENT VALUES('"+nombre+"','"+enfermedad+ "','"+numero+"')");
        bd.close();
    }
    }
    public void BuscarP(pacienteGS paciente, String nombre){
        SQLiteDatabase bd=getReadableDatabase();
        Cursor cursor=bd.rawQuery("SELECT * FROM PACIENT WHERE NOMBRE='"+nombre+"'", null);
        if(cursor.moveToFirst()){
            do{
              //  paciente.setNombre(cursor.getString(1));
                paciente.setEnfermedad(cursor.getString(1));
                paciente.setNumero(cursor.getString(2));
            }while (cursor.moveToNext());
        }

    }

}
