package co.edu.unipiloto.mymessenger;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SendMessageActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE="mensaje";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);

        Intent intent=getIntent();
        String mensajeTexto= intent.getStringExtra(EXTRA_MESSAGE);
        TextView mensajeView=(TextView) findViewById(R.id.textView);
        mensajeView.setText(mensajeTexto);
    }

}
